using System.Globalization;
using FluentTlsTunnel.Core;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
namespace FluentTlsTunnel;
public sealed partial class MainWindow : Window
{
    Profile profile = Profile.Load();
    Tunnel? tunnel;
    WindowsRouting? routing;
    TrayIcon? tray;
    TrayMenuWindow? trayMenu;
    bool exitRequested;
    CancellationTokenSource? cancel;
    bool loaded, busy, closing, allowClose;
    bool previewConnected;
    Task? connectingTask;
    TaskCompletionSource? connectionFinished;
    readonly System.Diagnostics.Stopwatch connectedClock=new();
    readonly SemaphoreSlim stopping = new(1,1);
    bool Arabic => profile.Language == "ar" || (profile.Language == "system" && CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "ar");
    string T(string en,string ar) => Arabic ? ar : en;
    readonly DispatcherTimer heartbeat = new() { Interval=TimeSpan.FromSeconds(1) };
    public MainWindow()
    {
        InitializeComponent();
        SystemBackdrop = new MicaBackdrop();
        ExtendsContentIntoTitleBar=true;SetTitleBar(AppTitleBar);
        var hwnd=WinRT.Interop.WindowNative.GetWindowHandle(this);
        var appWindow=AppWindow.GetFromWindowId(Win32Interop.GetWindowIdFromWindow(hwnd));
        appWindow.SetIcon(System.IO.Path.Combine(AppContext.BaseDirectory,"1-AppIcon.ico"));
        var area=DisplayArea.GetFromWindowId(appWindow.Id,DisplayAreaFallback.Primary).WorkArea;
        appWindow.Resize(new Windows.Graphics.SizeInt32(Math.Min(1120,area.Width-60),Math.Min(940,area.Height-60)));
        appWindow.Closing += async (_,e) =>
        {
            if(allowClose) return;
            e.Cancel=true;
            if(!exitRequested && !Environment.GetCommandLineArgs().Any(a=>a.StartsWith("--preview="))) {appWindow.Hide();return;}
            if(closing) return;
            closing=true;
            try {if(busy){cancel?.Cancel();if(connectionFinished!=null)await connectionFinished.Task;} await StopAsync(); }
            catch(Exception ex) { Log(ex.Message); closing=false; return; }
            tray?.Dispose();trayMenu?.Shutdown();allowClose=true; Close();
        };
        Host.Text=profile.Host; Port.Value=profile.Port; Sni.Text=profile.Sni; Username.Text=profile.Username;
        RouteWindows.IsChecked=profile.RouteWindows; Password.Password=PasswordStore.Load(profile);
        SocksPort.Value=profile.SocksPort; VerifyTls.IsChecked=profile.VerifyTls; Dns.Text=profile.DnsServers; UseDns.IsChecked=profile.UseDns;
        foreach(var a in DnsManager.Adapters()) Adapter.Items.Add(a);
        Adapter.SelectedItem=Adapter.Items.Cast<DnsManager.AdapterInfo>().FirstOrDefault(a=>a.Index==profile.AdapterIndex);
        Host.LostFocus+=(_,_)=>RefreshPassword();Username.LostFocus+=(_,_)=>RefreshPassword();Port.LostFocus+=(_,_)=>RefreshPassword();
        Language.SelectedIndex=profile.Language switch {"en"=>1,"ar"=>2,_=>0};
        Theme.SelectedIndex=profile.Theme switch {"light"=>1,"dark"=>2,_=>0};
        Nav.SelectedItem=ConnectionNav;
        loaded=true; Localize();
        if(!Environment.GetCommandLineArgs().Any(a=>a.StartsWith("--preview=")))
        {
            trayMenu=new TrayMenuWindow(TrayCommand);
            tray=new TrayIcon(hwnd,Path.Combine(AppContext.BaseDirectory,"1-AppIcon.ico"),Array.Empty<(int,string)>(),()=>{appWindow.Show();Activate();},TrayCommand,(x,y)=>{trayMenu.ShowAt(x,y,profile.Theme,Arabic,tunnel?.Connected==true,busy);return true;}){NativeTip=true};
            tray.SetTip("Fluent TLS Tunnel");
        }
        if(DnsManager.Pending) { Status.Severity=InfoBarSeverity.Warning; Status.Message=T("A DNS backup is pending. Restore DNS before a new connection.","توجد نسخة احتياطية لإعدادات DNS. استعد الإعدادات قبل اتصال جديد."); }
        Status.RegisterPropertyChangedCallback(InfoBar.MessageProperty,(_,_)=>Status.IsOpen=!string.IsNullOrEmpty(Status.Message));
        heartbeat.Tick += async (_,_) => { UpdateClock(); if(!busy && tunnel!=null && (!tunnel.Connected || (routing!=null && !routing.Healthy))) { Log(T("Connection lost.","انقطع الاتصال.")); try { await StopAsync(); } catch(Exception e) { Log(e.Message); } } };
        heartbeat.Start();
        var preview=Environment.GetCommandLineArgs().FirstOrDefault(a=>a.StartsWith("--preview="));
        if(preview!=null)
        {
            profile.Language=preview.Split('=')[1]; Language.SelectedIndex=profile.Language=="ar"?2:1;
            var mode=Environment.GetCommandLineArgs().FirstOrDefault(a=>a.StartsWith("--state="))?.Split('=')[1];
            previewConnected=mode=="connected";
            if(mode=="settings") Nav.SelectedItem=SettingsNav;
            if(mode=="about") Nav.SelectedItem=AboutNav;

            if(previewConnected) {profile.Host="demo.example";connectedClock.Start();}
            Localize();
            if(mode=="tray")
            {
                trayMenu=new TrayMenuWindow(TrayCommand);
                var showMenu=new DispatcherTimer{Interval=TimeSpan.FromSeconds(1)};showMenu.Tick+=(_,_)=>{showMenu.Stop();trayMenu.ShowAt(700,650,profile.Theme,Arabic,false,false);};showMenu.Start();
            }
        }
    }
    void NavChanged(NavigationView sender,NavigationViewSelectionChangedEventArgs e)
    {
        var page=(e.SelectedItem as NavigationViewItem)?.Tag?.ToString()??"connection";
        ConnectionPage.Visibility=page=="connection"?Visibility.Visible:Visibility.Collapsed;
        SettingsPage.Visibility=page=="settings"?Visibility.Visible:Visibility.Collapsed;
        AboutPanel.Visibility=page=="about"?Visibility.Visible:Visibility.Collapsed;
        ConnectionActions.Visibility=page=="connection"?Visibility.Visible:Visibility.Collapsed;
    }
    void Localize()
    {
        Root.FlowDirection=Arabic?FlowDirection.RightToLeft:FlowDirection.LeftToRight;
        Root.RequestedTheme=profile.Theme switch {"light"=>ElementTheme.Light,"dark"=>ElementTheme.Dark,_=>ElementTheme.Default};
        ProfileGroup.Text=T("CONNECTION PROFILE","إعدادات الاتصال");SettingsTitle.Text=T("Settings","الإعدادات");AppearanceGroup.Text=T("APPEARANCE AND LANGUAGE","المظهر واللغة");RoutingGroup.Text=T("ROUTING AND DNS","التوجيه وDNS");
        ConnectionNav.Content=T("Connection","الاتصال"); SettingsNav.Content=T("Settings","الإعدادات"); AboutNav.Content=T("About","حول التطبيق");
        foreach(var heading in new[]{UpdatesHeadingSettings,UpdatesHeadingAbout})heading.Text=T("Updates","التحديثات");
        foreach(var note in new[]{UpdatesNoteSettings,UpdatesNoteAbout})note.Text=T("The app never checks for updates on its own. Press the button to check once, right now.","لا يتحقق التطبيق من التحديثات من تلقاء نفسه. اضغط الزر للتحقق مرة واحدة الآن.");
        foreach(var text in new[]{InstalledVersionSettings,InstalledVersionAbout})text.Text=T("Installed version: v","الإصدار المثبت: v")+CurrentVersion;
        foreach(var button in new[]{CheckUpdatesSettings,CheckUpdatesAbout}){button.Content=T("Check for updates","التحقق من التحديثات");button.HorizontalAlignment=Arabic?HorizontalAlignment.Right:HorizontalAlignment.Left;}
        foreach(var link in new[]{UpdateLinkSettings,UpdateLinkAbout}){link.Content=T("Open download page","فتح صفحة التنزيل");link.HorizontalAlignment=Arabic?HorizontalAlignment.Right:HorizontalAlignment.Left;}
        VersionText.Text="v" + (typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "0.0.0");
        AboutDescription.Text=T("SSH over TLS with SNI, automatic Windows TCP routing and a local SOCKS5 proxy. UDP is not supported.","SSH عبر TLS مع SNI وتوجيه TCP تلقائي لويندوز ووكيل SOCKS5 محلي. لا يُدعم UDP.");
        DeveloperCredit.Text=T("Developed by Mohamed Elnaggar","تطوير محمد النجار");
        RepositoryLink.Content="GitHub Repo Link";
        Language.Header=T("Language","اللغة"); Theme.Header=T("Appearance","المظهر");
        Subtitle.Text=T("Connection","الاتصال");
        RouteWindows.Content=T("Route Windows traffic automatically (administrator permission)","توجيه اتصال ويندوز تلقائيًا (يتطلب صلاحية المسؤول)");
        ConnectionTitle.Text=T("Server & authentication","الخادم والمصادقة"); Host.Header=T("Server","الخادم"); Port.Header=T("Port","المنفذ"); Sni.Header="SNI";
        Username.Header=T("SSH username","اسم مستخدم SSH"); Password.Header=T("Password (saved securely)","كلمة المرور (تُحفظ بأمان)");
        VerifyTls.Content=T("Verify TLS certificate (recommended)","التحقق من شهادة TLS (موصى به)");
        TlsHint.Text=T("Some SSH-over-TLS services require this off. SSH host keys are still checked; disabling TLS verification weakens protection.","تتطلب بعض الخدمات تعطيل هذا الخيار. يستمر التحقق من مفتاح SSH، لكن تعطيل التحقق من TLS يقلل الحماية.");
        RoutingTitle.Text=T("Routing & DNS","التوجيه وDNS"); SocksPort.Header=T("Local SOCKS5 port","منفذ SOCKS5 المحلي");
        ProxyHint.Text=T("Automatic mode routes Windows TCP traffic through a virtual adapter. DNS goes through SSH. UDP apps are not supported; Windows VPN badges are not registered. Turn it off to use SOCKS5 manually.","يوجّه الوضع التلقائي اتصال TCP في ويندوز عبر محول افتراضي، وDNS عبر SSH. لا تُدعم تطبيقات UDP، ولا يُسجّل مؤشر VPN الرسمي. عطّله لاستخدام SOCKS5 يدويًا.");
        UseDns.Content=T("Use custom DNS while connected (administrator permission)","استخدام DNS مخصص أثناء الاتصال (يتطلب صلاحية المسؤول)");
        Adapter.Header=T("Network adapter","محول الشبكة"); Dns.Header=T("DNS server IP addresses","عناوين IP لخوادم DNS");
        DnsHint.Text=T("Manual SOCKS mode only. Automatic mode always uses DNS through SSH. Changes the selected Windows adapter, not remote SOCKS DNS. The old settings are backed up and restored on disconnect. After a crash, use Restore DNS. Windows asks for administrator approval each time.","خاص بوضع SOCKS اليدوي. يستخدم الوضع التلقائي DNS عبر SSH. يغيّر محول ويندوز المحدد، لا DNS البعيد في SOCKS. تُحفظ الإعدادات السابقة وتُستعاد عند قطع الاتصال. بعد تعطل التطبيق، اضغط استعادة DNS. يطلب ويندوز موافقة المسؤول لكل تغيير.");
        RestoreRouting.Content=T("Restore Windows routing","استعادة توجيه ويندوز");
        RestoreDns.Content=T("Restore DNS","استعادة DNS"); LogsPanel.Header=T("Connection log","سجل الاتصال");
        Import.Content=T("Import config","استيراد إعدادات"); Export.Content=T("Export config","تصدير إعدادات");
        Save.Content=T("Save profile","حفظ الإعدادات"); SetState();
    }
    void SettingsChanged(object sender,SelectionChangedEventArgs e)
    {
        if(!loaded) return;
        profile.Language=(Language.SelectedItem as ComboBoxItem)?.Tag?.ToString()??"system";
        profile.Theme=(Theme.SelectedItem as ComboBoxItem)?.Tag?.ToString()??"system";
        Localize();
    }
    void SetState()
    {
        bool connected=previewConnected || tunnel?.Connected==true;
        HeroTitle.Text=connected?T("Connected","متصل"):busy?T("Finding your private path…","جارٍ إنشاء مسارك الخاص…"):T("Ready when you are","جاهز عندما تكون مستعدًا");
        HeroDetail.Text=connected?(profile.RouteWindows?T("Windows TCP routing active · DNS through SSH","توجيه TCP في ويندوز نشط · DNS عبر SSH"):$"{profile.Host} · SOCKS5 127.0.0.1:{profile.SocksPort}"):T("Your apps. Your server. One connection.","تطبيقاتك. خادمك. اتصال واحد.");
        ConnectLabel.Text=busy?T("Cancel","إلغاء"):connected?T("Disconnect","قطع الاتصال"):T("Connect","اتصال");
        ConnectIcon.Symbol=connected?Symbol.Accept:busy?Symbol.Cancel:Symbol.Link;
        ConnectionTime.Visibility=connected?Visibility.Visible:Visibility.Collapsed; UpdateClock();
        StatusGlyph.Glyph=connected?"\uE73E":"\uE72E";
        if(connected) StatusGlyph.Foreground=(Brush)Application.Current.Resources["SystemFillColorSuccessBrush"]; else StatusGlyph.ClearValue(FontIcon.ForegroundProperty);
        Status.Severity=connected?InfoBarSeverity.Success:InfoBarSeverity.Informational;
        foreach(var control in new Control[]{Host,Port,Sni,Username,Password,SocksPort,VerifyTls,UseDns,Adapter,Dns,Save,Import,Export,Language,Theme,RestoreDns,RestoreRouting,RouteWindows}) control.IsEnabled=!busy && tunnel==null;
    }
    Profile ReadProfile()
    {
        profile.Host=Host.Text.Trim(); profile.Port=checked((int)Port.Value); profile.Sni=Sni.Text.Trim(); profile.Username=Username.Text.Trim();
        profile.RouteWindows=RouteWindows.IsChecked==true;
        profile.SocksPort=checked((int)SocksPort.Value); profile.VerifyTls=VerifyTls.IsChecked==true; profile.UseDns=UseDns.IsChecked==true;
        profile.DnsServers=Dns.Text.Trim(); profile.AdapterIndex=(Adapter.SelectedItem as DnsManager.AdapterInfo)?.Index??0;
        if(profile.RouteWindows)profile.UseDns=false;
        profile.Validate(); return profile;
    }
    void Log(string message) => DispatcherQueue.TryEnqueue(()=>
    {
        if(message=="tls-ready") message=T("TLS ready.","اتصال TLS جاهز.");
        if(message=="connected") message=T("SSH ready. Local SOCKS5 is listening.","اتصال SSH جاهز. يعمل SOCKS5 المحلي.");
        Logs.Text=($"{DateTime.Now:HH:mm:ss} {message}\n"+Logs.Text);
        if(Logs.Text.Length>12000) Logs.Text=Logs.Text[..12000];
    });
    Task<bool> ConfirmKey(string endpoint,string key,bool changed)
    {
        var result=new TaskCompletionSource<bool>();
        DispatcherQueue.TryEnqueue(async ()=>
        {
            try
            {
                var dialog=new ContentDialog { XamlRoot=Root.XamlRoot, Title=changed?T("SSH host key changed","تغيّر مفتاح خادم SSH"):T("Trust this SSH server?","هل تثق بخادم SSH؟"),
                    Content=endpoint+"\n\n"+key+"\n\n"+T("Compare this fingerprint with your provider before accepting. A changed key may mean an attack or a replaced server.","تحقق من هذه البصمة لدى مزود الخدمة قبل الموافقة. قد يدل تغير المفتاح على هجوم أو استبدال الخادم."),
                    PrimaryButtonText=T("Trust key","الثقة بالمفتاح"), CloseButtonText=T("Cancel","إلغاء"), DefaultButton=ContentDialogButton.Close };
                result.TrySetResult(await dialog.ShowAsync()==ContentDialogResult.Primary);
            } catch { result.TrySetResult(false); }
        });
        return result.Task;
    }
    async void ConnectClick(object sender,RoutedEventArgs e)
    {
        if(busy) { cancel?.Cancel(); return; }
        if(tunnel!=null) { try { await StopAsync(); } catch(Exception ex) { Status.Message=ex.Message; } return; }
        try
        {
            var p=ReadProfile();
            if(DnsManager.Pending) throw new InvalidOperationException(T("Restore the pending DNS backup first.","استعد إعدادات DNS السابقة أولًا."));
            if(Password.Password.Length==0) throw new ArgumentException(T("Enter your password.","أدخل كلمة المرور."));
            PasswordStore.Save(p,Password.Password);p.Save();connectionFinished=new(TaskCreationOptions.RunContinuationsAsynchronously); busy=true; Status.Message=""; cancel=new(); tunnel=new(); SetState();
            var password = Password.Password;
            connectingTask=Task.Run(()=>tunnel.ConnectAsync(p,password,ConfirmKey,Log,cancel.Token));
            await connectingTask;
            cancel.Token.ThrowIfCancellationRequested();
            if(p.RouteWindows){routing=new();await routing.StartAsync(tunnel.RemoteAddress??throw new InvalidOperationException("TLS endpoint unavailable"),p.SocksPort,cancel.Token);}
            if(p.UseDns && !p.RouteWindows) await DnsManager.ApplyAsync(p.AdapterIndex,Profile.ParseDns(p.DnsServers));
            connectedClock.Restart(); ShowConnectedNotification();

            Status.Message=p.RouteWindows?T("Windows TCP routing is active. UDP is not supported.","توجيه TCP في ويندوز نشط. لا يُدعم UDP."):$"SOCKS5 · 127.0.0.1:{p.SocksPort}";
        }
        catch(Exception ex) { Log(ex.Message); try { await StopAsync(); } catch(Exception restore) { Log(restore.Message); } Status.Message=ex.Message; }
        finally { busy=false; connectingTask=null; SetState();connectionFinished?.TrySetResult(); }
    }
    async Task StopAsync()
    {
        cancel?.Cancel();
        if(connectingTask!=null) try { await connectingTask; } catch { }
        await stopping.WaitAsync();
        try
        {
            if(routing!=null){await routing.DisposeAsync();routing=null;}
            if(tunnel!=null) { await Task.Run(async ()=>await tunnel.DisposeAsync()); tunnel=null; }
            if(DnsManager.Pending) await DnsManager.RestoreAsync();
            cancel?.Dispose(); cancel=null; connectedClock.Reset(); SetState();
        }
        finally { stopping.Release(); }
    }
    void SaveClick(object sender,RoutedEventArgs e) { try { var p=ReadProfile();PasswordStore.Save(p,Password.Password);p.Save(); Status.Message=T("Profile and password saved securely.","حُفظت الإعدادات وكلمة المرور بأمان."); } catch(Exception ex) { Status.Message=ex.Message; } }
    async void RestoreRoutingClick(object sender,RoutedEventArgs e){try{await WindowsRouting.RestoreAsync();Status.Message=T("Windows routing restored.","استُعيد توجيه ويندوز.");}catch(Exception ex){Status.Message=ex.Message;}}
    async void RestoreDnsClick(object sender,RoutedEventArgs e) { try { await DnsManager.RestoreAsync(); Status.Message=T("Previous DNS settings restored.","استُعيدت إعدادات DNS السابقة."); } catch(Exception ex) { Status.Message=ex.Message; } }
    async void ExportClick(object sender,RoutedEventArgs e)
    {
        try
        {
            var p=ReadProfile();
            var picker=new Windows.Storage.Pickers.FileSavePicker { SuggestedFileName="fluent-tls-config" };
            picker.FileTypeChoices.Add("Tunnel configuration",new List<string>{".ftlsc"});
            WinRT.Interop.InitializeWithWindow.Initialize(picker,WinRT.Interop.WindowNative.GetWindowHandle(this));
            var file=await picker.PickSaveFileAsync(); if(file==null) return;
            // Export network settings only. Never export passwords or trust records.
            var portable=new Profile { Host=p.Host,Port=p.Port,Sni=p.Sni,Username=p.Username,SocksPort=p.SocksPort,VerifyTls=p.VerifyTls,DnsServers=p.DnsServers };
            var protection=await ExportProtection(); if(!protection.Proceed) return;
            await Windows.Storage.FileIO.WriteTextAsync(file,ConfigCrypto.Encode(portable,protection.Password));
            Status.Message=T("Config exported without passwords or trusted keys.","صُدّرت الإعدادات دون كلمات مرور أو مفاتيح موثوقة.");
        } catch(Exception ex) { Status.Message=ex.Message; }
    }
    async void ImportClick(object sender,RoutedEventArgs e)
    {
        try
        {
            var picker=new Windows.Storage.Pickers.FileOpenPicker(); picker.FileTypeFilter.Add(".ftlsc");
            WinRT.Interop.InitializeWithWindow.Initialize(picker,WinRT.Interop.WindowNative.GetWindowHandle(this));
            var file=await picker.PickSingleFileAsync(); if(file==null) return;
            if((await file.GetBasicPropertiesAsync()).Size>65536) throw new ArgumentException(T("Config file is too large.","ملف الإعدادات كبير جدًا."));
            var content=await Windows.Storage.FileIO.ReadTextAsync(file);
            string? secret=null; if(ConfigCrypto.Encrypted(content)) {var answer=await ImportPassword(); if(answer==null) return; secret=answer;}
            var p=ConfigCrypto.Decode(content,secret);
            p.UseDns=false; p.AdapterIndex=0; p.RouteWindows=false; p.Validate(); Profile.ParseDns(p.DnsServers);
            var dialog=new ContentDialog {XamlRoot=Root.XamlRoot,Title=T("Import these settings?","هل تريد استيراد هذه الإعدادات؟"),Content=$"{p.Host}:{p.Port}\nSNI: {p.Sni}\nSSH: {p.Username}\nSOCKS: {p.SocksPort}\nDNS: {p.DnsServers}",PrimaryButtonText=T("Import","استيراد"),CloseButtonText=T("Cancel","إلغاء"),DefaultButton=ContentDialogButton.Close};
            if(await dialog.ShowAsync()!=ContentDialogResult.Primary) return;
            Host.Text=p.Host;Port.Value=p.Port;Sni.Text=p.Sni;Username.Text=p.Username;SocksPort.Value=p.SocksPort;VerifyTls.IsChecked=p.VerifyTls;Dns.Text=p.DnsServers;UseDns.IsChecked=false;

            Status.Message=T("Config imported. Review it before connecting. DNS changes remain off.","استُوردت الإعدادات. راجعها قبل الاتصال. يبقى تغيير DNS معطّلًا.");
        } catch(Exception ex) { Status.Message=ex.Message; }
    }

    async Task<(bool Proceed,string? Password)> ExportProtection()
    {
        var check=new CheckBox {Content=T("Encrypt with a password","التشفير بكلمة مرور")};
        var secret=new PasswordBox {Header=T("Export password (at least 8 characters)","كلمة مرور التصدير (8 أحرف على الأقل)")};
        var stack=new StackPanel {Spacing=12};stack.Children.Add(check);stack.Children.Add(secret);
        var dialog=new ContentDialog {XamlRoot=Root.XamlRoot,Title=T("Protect this config","حماية ملف الإعدادات"),Content=stack,PrimaryButtonText=T("Export","تصدير"),CloseButtonText=T("Cancel","إلغاء")};
        if(await dialog.ShowAsync()!=ContentDialogResult.Primary) return (false,null);
        if(check.IsChecked==true && secret.Password.Length<8) throw new ArgumentException(T("Use at least 8 characters for the export password.","استخدم 8 أحرف على الأقل لكلمة مرور التصدير."));
        return (true,check.IsChecked==true?secret.Password:null);
    }
    async Task<string?> ImportPassword()
    {
        var secret=new PasswordBox {Header=T("Config password","كلمة مرور ملف الإعدادات")};
        var dialog=new ContentDialog {XamlRoot=Root.XamlRoot,Title=T("Encrypted config","ملف إعدادات مشفّر"),Content=secret,PrimaryButtonText=T("Unlock","فتح"),CloseButtonText=T("Cancel","إلغاء")};
        return await dialog.ShowAsync()==ContentDialogResult.Primary?secret.Password:null;
    }

    static string CurrentVersion=>typeof(MainWindow).Assembly.GetName().Version?.ToString(3)??"0.1.2";
    bool checkingUpdate;
    async void CheckUpdatesClick(object sender,RoutedEventArgs e)
    {
        if(checkingUpdate)return;checkingUpdate=true;
        CheckUpdatesSettings.IsEnabled=CheckUpdatesAbout.IsEnabled=false;
        UpdateLinkSettings.Visibility=UpdateLinkAbout.Visibility=Visibility.Collapsed;
        UpdateResultSettings.Text=UpdateResultAbout.Text=T("Checking...","جارٍ التحقق...");
        try
        {
            using var http=new HttpClient{Timeout=TimeSpan.FromSeconds(20)};
            http.DefaultRequestHeaders.UserAgent.ParseAdd("FluentTlsTunnel/"+CurrentVersion);
            using var response=await http.GetAsync("https://api.github.com/repos/MohamedElnaggar00/fluent-tls-tunnel/releases?per_page=30");response.EnsureSuccessStatusCode();
            using var json=System.Text.Json.JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            Version? newest=null;Uri? url=null;
            foreach(var r in json.RootElement.EnumerateArray())
            {
                if(r.TryGetProperty("draft",out var draft)&&draft.GetBoolean())continue;
                var tag=(r.GetProperty("tag_name").GetString()??"").TrimStart('v','V');
                if(Version.TryParse(tag,out var v)&&(newest==null||v>newest)&&Uri.TryCreate(r.GetProperty("html_url").GetString(),UriKind.Absolute,out var u)&&u.Host=="github.com"){newest=v;url=u;}
            }
            string result;
            if(newest==null)result=T("No releases found yet.","لا توجد إصدارات بعد.");
            else if(newest>Version.Parse(CurrentVersion))
            {
                result=T($"Version {newest} is available.",$"الإصدار {newest} متاح.");
                UpdateLinkSettings.NavigateUri=UpdateLinkAbout.NavigateUri=url;
                UpdateLinkSettings.Visibility=UpdateLinkAbout.Visibility=Visibility.Visible;
            }
            else result=T($"You're up to date (v{CurrentVersion}).",$"أنت على أحدث إصدار (v{CurrentVersion}).");
            UpdateResultSettings.Text=UpdateResultAbout.Text=result;
        }
        catch{UpdateResultSettings.Text=UpdateResultAbout.Text=T("Couldn't check for updates. Check your internet connection and try again.","تعذر التحقق من التحديثات. تحقق من اتصالك بالإنترنت وحاول مرة أخرى.");}
        finally{checkingUpdate=false;CheckUpdatesSettings.IsEnabled=CheckUpdatesAbout.IsEnabled=true;}
    }
    string passwordIdentity="";
    void RefreshPassword()
    {
        var p=new Profile{Host=Host.Text.Trim(),Port=(int)Port.Value,Username=Username.Text.Trim()};
        var key=p.Endpoint+"/"+p.Username;
        if(passwordIdentity.Length==0)passwordIdentity=profile.Endpoint+"/"+profile.Username;
        if(key!=passwordIdentity){Password.Password=PasswordStore.Load(p);passwordIdentity=key;}
    }
    void TrayCommand(int command)
    {
        if(command==4){exitRequested=true;Close();return;}
        AppWindow.Show();Activate();
        if(command==2)Nav.SelectedItem=SettingsNav;
        else if(command==3)Nav.SelectedItem=AboutNav;
        else {Nav.SelectedItem=ConnectionNav;ConnectClick(ConnectButton,new RoutedEventArgs());}
    }
    void UpdateClock()
    {
        var elapsed=connectedClock.Elapsed;
        ConnectionTime.Text=$"{(int)elapsed.TotalHours:00}:{elapsed.Minutes:00}:{elapsed.Seconds:00}";
    }
    void ShowConnectedNotification()
    {
        try
        {
            var notification=new Microsoft.Windows.AppNotifications.Builder.AppNotificationBuilder()
                .AddText("Fluent TLS Tunnel").AddText(T("Connected","متصل")).BuildNotification();
            Microsoft.Windows.AppNotifications.AppNotificationManager.Default.Show(notification);
        }
        catch { Log(T("Windows notifications are unavailable.","إشعارات ويندوز غير متاحة.")); }
    }

}
